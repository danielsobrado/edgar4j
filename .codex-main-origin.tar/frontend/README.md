
  # Financial Data Dashboard

  This is a code bundle for Financial Data Dashboard. The original project is available at https://www.figma.com/design/i4G0SMx0HOyySsAgIWQSvp/Financial-Data-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  